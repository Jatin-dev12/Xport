/* eslint-disable no-unused-vars */
import { useState, useEffect } from 'react';
import { getFirestore, collection, getDocs } from 'firebase/firestore';
import { Chart, registerables } from 'chart.js';
import {
  Spinner,
  Flex,
  Text,
  Button,
  VStack,
  Grid,
  GridItem,
} from '@chakra-ui/react';

// Register Chart.js components
Chart.register(...registerables);

function List() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedCard, setSelectedCard] = useState(null); // Add a state to store the selected card

  useEffect(() => {
    const fetchData = async () => {
      const db = getFirestore();
      const collectionRef = collection(db, 'Jatin');

      try {
        const querySnapshot = await getDocs(collectionRef);
        const allData = {};

        querySnapshot.forEach((doc) => {
          allData[doc.id] = doc.data();
        });

        setData(allData);
      } catch (error) {
        console.error('Error fetching documents: ', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Define card labels
  const cardLabels = [
    'Card 1',
    'Card 2',
    'Card 3',
    'Card 4',
    'Card 5',
    'Card 6',
    'Card 7',
    'Card 8',
    'Card 9',
    'Card 10',
    'Card 11',
    'Card 12',
  ];

  const totalRespondents = data ? Object.keys(data).length : 5;

  let ratingDistribution = {};
  let ratingDistributionList = [];

  if (data) {
    ratingDistribution = cardLabels.reduce((acc, cardLabel, index) => {
      acc[cardLabel] = [0, 0, 0, 0, 0]; // Initialize rating counts for each card
      Object.keys(data).forEach((docId) => {
        const cardData = data[docId][`card${index + 1}`];
        if (cardData) {
          const rating = parseInt(cardData, 10);
          acc[cardLabel][rating - 1]++; // Increment the corresponding rating count
        }
      });
      return acc;
    }, {});

    const chartData = cardLabels.map((cardLabel, index) => {
      const ratings = ratingDistribution[cardLabel];
      return {
        label: cardLabel,
        data: ratings,
        backgroundColor: [
          'rgba(255, 99, 132, 0.2)',
          'rgba(54, 162, 235, 0.2)',
          'rgba(255, 206, 86, 0.2)',
          'rgba(75, 192, 192, 0.2)',
          'rgba(153, 102, 255, 0.2)',
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)',
        ],
        borderWidth: 1,
      };
    });

    // Calculate total respondents for each card
    const totalRespondentsData = cardLabels.map((cardLabel) => {
      let count = 0;
      Object.keys(data).forEach((docId) => {
        if (data[docId][cardLabel]) {
          count++;
        }
      });
      return count;
    });

    // Create a new line chart to display total respondents
    const lineChartData = {
      labels: cardLabels,
      datasets: [{
        label: 'Total Respondents',
        data: totalRespondentsData,
        backgroundColor: 'rgba(255, 99, 132, 0.2)',
        borderColor: 'rgba(255, 99, 132, 1)',
        borderWidth: 1,
      }],
    };

    return (
      <VStack spacing={4} align="stretch" p={4}>
    {loading ? (
      <Spinner
        thickness="4px"
        speed="0.65s"
        emptyColor="gray.200"
        color="blue.500"
        size="xl"
      />
    ) : (
      <Grid templateColumns="repeat(3, 1fr)" gap={8} m={2}>
        {chartData.map((chart, index) => (
          <GridItem key={index} colSpan={1} p={6} borderRadius="md" boxShadow="md">
            <canvas id={`chart-${index}`} />
            {new Chart(
              document.getElementById(`chart-${index}`),
              {
                type: 'bar',
                data: {
                  labels: ['Option 1', 'Option 2', 'Option 3', 'Option 4', 'Option 5'],
                  datasets: [chart],
                },
              }
            )}
          </GridItem>
        ))}
        {/* Add a new GridItem to render the line chart */}
        <GridItem colSpan={3} p={6} borderRadius="md" boxShadow="md">
          <canvas id="line-chart" />

        </GridItem>
      </Grid>
    )}
  </VStack>
    );
  }
}

export default List;